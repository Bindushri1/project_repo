/*package com.psl.training.service;

import java.util.List;


import com.psl.training.model.User;

public interface UserService {
  public User addUser(User  user) ;
	  public List<User> getAllUser();
	  public User getUserById(int userId);
	
	
  }
*/
