package com.psl.training.model;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity
@Table (name="appointment")
public class Appointment {
	@Id
	@GeneratedValue
        
	   private Long id;
       @NotBlank
       private String dr_name;
	
	

       
       
       public Appointment() {
    	   super();
       }
       
       
       public Appointment(Long id, String dr_name) {
           super();
           this.id = id;
           this.dr_name = dr_name;
       }
           
        public Long getid() {
        	return id;
        }
        
        public void setid(Long id) {
        	this.id=id;
        }

       public String getdr_name() {
    	   return dr_name;
       }
       
       public void setdr_name(String dr_name) {
    	   this.dr_name=dr_name;
       }


	
} 

