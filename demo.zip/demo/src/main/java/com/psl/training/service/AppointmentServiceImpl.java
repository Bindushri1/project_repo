/*package com.psl.training.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.psl.training.model.Appointment;
import com.psl.training.repository.AppointmentRepository;

@Service
public  class AppointmentServiceImpl  implements AppointmentService{
	@Autowired
	
	private AppointmentRepository appointmentRepository;
	
	@Override
	public Appointment addAppointment(Appointment appointment) {
		return appointmentRepository.save(appointment);
	}


	@Override
	public List<Appointment> getAllAppointment() {
		// TODO Auto-generated method stub
		return (List<Appointment>) appointmentRepository.findAll();
	}

	@Override
	public Appointment getAppointmentById(long appointmentId) {
		// TODO Auto-generated method stub
		return appointmentRepository.findById(appointmentId).get();
	}


	@Override
	public Appointment getAppointmentById(int appointmentId) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void delete(Appointment appointment) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public List<Appointment> findAll() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Object findById(Long appointmentId) {
		// TODO Auto-generated method stub
		return null;
	}

}*/
