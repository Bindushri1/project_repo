package com.psl.training;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;
 
@SpringBootApplication
public class DemoApplication implements CommandLineRunner {
     
    @Autowired
    private JdbcTemplate jdbcTemplate;
     
    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }
 
    @Override
    public void run(String... args) throws Exception {
        String sql = "INSERT INTO users (fstname, lastname, email, password,id) VALUES (?, ?, ?,?,?)";
         
        int result = jdbcTemplate.update(sql, "Ravi"," Kumar", "ravi.kumar@gmail.com", "ravi2021",1);
        
        String sql1 = "INSERT INTO login(mail,password) VALUES(?,?)";
         @SuppressWarnings("unused")
		int result1 = jdbcTemplate.update(sql1,"manoj.s@gmail.com","ravi2021");
         
         String sql2 = "INSERT INTO appointment(dr_name,id) VALUES(?,?)";
         @SuppressWarnings("unused")
		int result2 = jdbcTemplate.update(sql2,"SUMA",1);
         
        if (result > 0) {
            System.out.println("A new row has been inserted.");
        }
         
    }
 
}
