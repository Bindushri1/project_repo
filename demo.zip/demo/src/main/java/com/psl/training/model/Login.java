package com.psl.training.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity
@Table (name="login")
public class Login {
	@Id
	@GeneratedValue
   
       @NotBlank
       private String mail;
       
       @NotBlank
       private String password;
       
       
       public Login() {
    	   super();
       }
       
       public Login(String mail,String password) {
    	   super();
    	   
    	   this.mail=mail;
    	   this.password=password;
       }
       

       public String getmail() {
    	   return mail;
       }
       
       public void setmail(String mail) {
    	   this.mail=mail;
       }
       
       public String getpassword() {
    	   return password;
       }
       public void setpassword(String password) {
    	   this.password=password;
       }
} 

