package com.psl.training.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity
@Table (name="users")
public class User {
	@Id
	@GeneratedValue
	
	private Long id;
   
       @NotBlank
       private String fstname;
       
       @NotBlank
       private String lastname;
       
       @NotBlank
       private String password;
       
       @NotBlank
       private String email;
       
       public User() {
    	   super();
       }
       
       public User(String fstname,String lastname,String password,String email, Long id) {
    	   super();
    	   this.id=id; 
    	   this.fstname=fstname;
    	   this.lastname=lastname;
    	   this.email=email;
    	   this.password=password;
       }
       
       
       
       public Long getid() {
    	   return id;
       }
       
       public void setid(Long id) {
    	   this.id=id;
       }
       
       
       public String getfstname() {
    	   return fstname;
       }
       
       public void setfstname(String fstname) {
    	   this.fstname=fstname;
       }
       
       
       
       public String getlastname() {
    	   return lastname;
       }
       
       public void setlastname(String lastname) {
    	   this.lastname=lastname;
       }
       
       
       
       public String getemail() {
    	   return email;
       }
       
       public void setemail(String email) {
    	   this.email=email;
       }
       
       
       
       public String getpassword() {
    	   return password;
       }
       public void setpassword(String password) {
    	   this.password=password;
       }

	
} 
