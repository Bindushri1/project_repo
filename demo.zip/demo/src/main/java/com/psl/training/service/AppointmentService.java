/*package com.psl.training.service;

import java.util.List;

import com.psl.training.model.Appointment;


public interface AppointmentService {
	
	public Appointment addAppointment(Appointment appointment);
	
	public List<Appointment> getAllAppointment();
	
	
	
}
*/



